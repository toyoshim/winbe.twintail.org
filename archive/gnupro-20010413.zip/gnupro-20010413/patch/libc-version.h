#ifndef LIBC_VERSION_h
#define LIBC_VERSION_h

#ifdef __cplusplus
extern "C" {
#endif

const char *
gnu_get_libc_version(void);

#ifdef __cplusplus
}
#endif
#endif
