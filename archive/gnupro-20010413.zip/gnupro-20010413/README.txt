binutils-2.10.1 / gcc-2.95.3 (core/g++)

*** INSTALL ***

% cd /boot/develop/tools
% unzip gnupro-20010413.zip
% mv gnupro gnupro.orig
% ln -s gnupro-20010413 gnupro

*** NOTICE ***

If you want to build mozilla, you should prepare
/boot/develop/headers/gnu/libc-version.h.

% cp /boot/develop/tools/gnupro/patch/libc-version.h /boot/develop/headers/gnu/

----
Takashi Toyoshima <toyoshim@be-in.org>
http://www.toyoshima-house.net/
